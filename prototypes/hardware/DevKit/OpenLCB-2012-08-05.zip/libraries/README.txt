The EthernetDNS, EthernetDHCP and EthernetBonjour
are used under license from 
http://gkaindl.com/software/arduino-ethernet

Other libraries that might be of interest:

DCCPacketQueue
CmdrArduino


