#ifndef __OLCB_BUFFER_H__
#define __OLCB_BUFFER_H__

#define OLCB_Buffer OLCB_CAN_Buffer //HACK!!

#include "OLCB_CAN_Buffer.h"

#endif //__OLCB_BUFFER_H__
