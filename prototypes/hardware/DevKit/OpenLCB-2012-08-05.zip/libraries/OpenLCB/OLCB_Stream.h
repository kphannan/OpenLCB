#ifndef __OLCB_STREAM_H__
#define __OLCB_STREAM_H__

class OLCB_Stream
{
};

#endif
