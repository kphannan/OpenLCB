#ifndef OlcbCommonVersion_h
#define OlcbCommonVersion_h

/**
 * Define the library version.
 *
 */

#define OlcbCommonVersion "0.6.1"

#endif
