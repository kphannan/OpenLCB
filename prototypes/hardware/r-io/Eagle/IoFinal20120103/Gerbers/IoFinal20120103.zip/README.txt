Io PCB

Hi-

I would like to have 50 boards manufactured and assembled.  

I have included a BOM xls file with links to Mouser parts.  
Mouser has all the parts except for the 863-NUP2105LT1G, 
which I will source separately.  

There are some through-hole parts that will be left as optional installs, 
and these are indicated.  

Can you please send me: 

1. A quote for manufacture
   50 pcbs; 
   Blue board colour;
   White Silk Screen.  
   Standard defaults for board thickness, holes, etc.  
2. Quote for electrical testing; 
3. Quote for assembly;  
4. Instructions on how to ship the parts to you factory.  

You can reach me at: drdpharris@gmail.com
Cell / Office: 1-250-216-0641
Home: 1-250-370-2323

Address: 
  Dr. David Harris
  1545 York Place
  Victoria, BC
  V8R 5X1

Thank you,
David
