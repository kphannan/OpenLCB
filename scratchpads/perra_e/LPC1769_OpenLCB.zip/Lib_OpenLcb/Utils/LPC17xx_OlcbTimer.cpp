/*
 * LPC17xx_OlcbTimer.cpp
 *
 *  Created on: 1 feb 2011
 *      Author: per
 */

#include "LPC17xx_OlcbTimer.h"
#include "lpc17xx_gpio.h"
#include "lpc17xx_pinsel.h"
#include "lpc17xx_timer.h"
#include "WConstants.h"


uint32_t _count=0;
long _millisec=0;
uint32_t _microsec=0;

TIM_TIMERCFG_Type TIM_ConfigStruct;
TIM_CAPTURECFG_Type TIM_CaptureConfigStruct;


/************************** PRIVATE FUNCTIONS *************************/
void TIMER0_IRQHandler(void);

/*----------------- INTERRUPT SERVICE ROUTINES --------------------------*/
/*********************************************************************//**
 * @brief 		TIMER0 interrupt handler
 * @param		None
 * @return 		None
 ***********************************************************************/
void TIMER0_IRQHandler(void)
{

	if (TIM_GetIntCaptureStatus(LPC_TIM0, TIM_MR0_INT))
	{
		TIM_ClearIntCapturePending(LPC_TIM0, TIM_MR0_INT);
		_microsec++ ;
		if(_count++ == 1000)
		{
			_millisec++;
//			UpdateMillis(_millisec);
		}
	}

}

/************************** PUBLIC FUNCTIONS  **************************/

long LPC17xx_OlcbTimer::millisec()
{
	return _millisec;
}
void LPC17xx_OlcbTimer::init()
{


	//
	// Initialize timer 0 with a prescale count time of 5uS
	// This will give 200 steps for servos that use between 0,5ms and 1,5ms
	// between end positions
	//

	TIM_ConfigStruct.PrescaleOption = TIM_PRESCALE_USVAL;
	TIM_ConfigStruct.PrescaleValue	= 5;

	TIM_Init(LPC_TIM0, TIM_TIMER_MODE,&TIM_ConfigStruct);

	// use channel 0, CAPn.0
	TIM_CaptureConfigStruct.CaptureChannel = 0;
	// Enable capture on CAPn.0 rising edge
	TIM_CaptureConfigStruct.RisingEdge = ENABLE;
	// Enable capture on CAPn.0 falling edge
	TIM_CaptureConfigStruct.FallingEdge = DISABLE;
	// Generate capture interrupt
	TIM_CaptureConfigStruct.IntOnCaption = ENABLE;

	// Set configuration for Tim_config and Tim_MatchConfig
	TIM_Init(LPC_TIM0, TIM_TIMER_MODE,&TIM_ConfigStruct);
	TIM_ConfigCapture(LPC_TIM0, &TIM_CaptureConfigStruct);
	TIM_ResetCounter(LPC_TIM0);

	/* preemption = 1, sub-priority = 1 */
	NVIC_SetPriority(TIMER0_IRQn, ((0x01<<3)|0x01));
	/* Enable interrupt for timer 0 */
	NVIC_EnableIRQ(TIMER0_IRQn);
	// To start timer 0
	TIM_Cmd(LPC_TIM0,ENABLE);
}
