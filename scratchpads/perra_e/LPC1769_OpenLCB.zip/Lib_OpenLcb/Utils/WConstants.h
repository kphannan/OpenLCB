// Arduino stand-in
#include <stdint.h>
#include "EEPROM.h"


extern "C"
{
	void RIT_IRQHandler(void);
}


void InitTimers(void);

long millis();

int min(int a, int b);

