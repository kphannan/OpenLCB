#ifndef logging_h
#define logging_h

/**
 * Provide generic CAN interface for OpenLcb code
 *
 * Heavily modelled on CAN.h, but intended to abstract
 * CAN access so that other hardware and software solutions
 * can be provided in the future.
 *
 */

class Logging;


#endif
