/*
 * LPC17xx_OlcbTimer.h
 *
 *  Created on: 26 jan 2011
 *      Author: per
 */

#ifndef LPC17XX_OLCBTIMER_H_
#define LPC17XX_OLCBTIMER_H_

#include <stdint.h>
#include "lpc17xx_timer.h"

class LPC17xx_OlcbTimer
{
public:

	void init(void);
	long millisec();

private:
	void TIMER0_IRQHandler(void);

};
#endif /* LPC17XX_OLCBTIMER_H_ */
