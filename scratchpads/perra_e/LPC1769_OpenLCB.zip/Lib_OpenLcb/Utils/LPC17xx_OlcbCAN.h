/*
 * LPC17xx_OlcbCAN.h
 *
 *  Created on: 26 jan 2011
 *      Author: per
 */

#ifndef LPC17XX_OLCBCAN_H_
#define LPC17XX_OLCBCAN_H_

#include <stdint.h>
#include "lpc17xx_can.h"
#include "CAN.h"

extern "C" {
	void CAN_IRQHandler(void);

} // extern "C"


	void can_init(void);
	uint8_t can_buffers_status(void);
	uint8_t can_send_message(const tCAN *msg);
	uint8_t can_get_buffered_message(tCAN *msg);
	void can_copy_buf_to_message(tCAN *msg);

#endif /* LPC17XX_OLCBCAN_H_ */
