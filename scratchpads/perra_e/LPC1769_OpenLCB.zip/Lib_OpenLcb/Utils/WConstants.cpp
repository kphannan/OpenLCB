// Arduino stand-in
#include <stdint.h>
#include "lpc17xx_rit.h"

#define TIME_INTERVAL 	1

uint32_t _count=0;
long _millisec=0;

/************************** PRIVATE FUNCTION *************************/


/*----------------- INTERRUPT SERVICE ROUTINES --------------------------*/
/*********************************************************************//**
 * @brief		RIT interrupt handler sub-routine
 * @param[in]	None
 * @return 		None
 **********************************************************************/
extern "C"
{
	void RIT_IRQHandler(void)
	{
		RIT_GetIntStatus(LPC_RIT); //call this to clear interrupt flag
		_millisec++;
	}
}


void InitTimers(void)
{

	RIT_Init(LPC_RIT);
	/* Configure time_interval for RIT
	 * In this case: time_interval = 1 ms
	 * So, RIT will generate interrupt each 1s
	 */
	RIT_TimerConfig(LPC_RIT, TIME_INTERVAL);
	NVIC_EnableIRQ(RIT_IRQn);

}


long millis()
{
	return _millisec;
}

int min(int a, int b) {
    return (a<b) ? a : b;
};
