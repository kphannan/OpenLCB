/**
 * Specific implementation for CAN.h MP2515
 */
#include "CAN.h"
#include "LPC17xx_OlcbCAN.h"

#include "OpenLcbCanInterface.h"
#include "OpenLcbCanBuffer.h"
#include "can_buffer.h"

void OpenLcb_can_init() {
    can_init();
}

// Can a (the) CAN buffer be used?  
// Generally, indicates the buffer can be immediately
// queued for transmit, so it make sense to prepare it now

bool OpenLcb_can_xmt_ready(OpenLcbCanBuffer* b) {

	uint8_t status = can_buffers_status();

	// Check to see if all transmit buffers are all free
	  //TODO get the right check here

	if((status>>2)& 0x01)
	    return true;   // All available. *Original at least one has space
	  else
	    return false;  // Any full. *Original Both at full
}

// Queue a CAN frame for sending, if possible
// Returns true if queued, false if not currently possible
bool OpenLcb_can_queue_xmt_immediate(OpenLcbCanBuffer* b) {
  if (!OpenLcb_can_xmt_ready(b)) return false;
  // buffer available, queue for send
  can_send_message(b);
  return true;
}

// Queue a CAN frame for sending; spins until it can queue
void OpenLcb_can_send_xmt(OpenLcbCanBuffer* b) {
  OpenLcb_can_queue_xmt_wait(b);
  // wait for sent
  while (!OpenLcb_can_xmt_idle()) {}
}


void OpenLcb_can_queue_xmt_wait(OpenLcbCanBuffer* b) {
  while (!OpenLcb_can_queue_xmt_immediate(b)) {};
}

// Send a CAN frame, waiting until it has been sent
// Check whether all frames have been sent,
// a proxy for the link having gone idle
bool OpenLcb_can_xmt_idle() {

	uint8_t status = can_buffers_status();

	// Check to see if all transmit buffers are all free
	  //TODO get the right check here

	if((status>>2)& 0x01)
	    return true;   // All available.
	  else
	    return false;  // Any full
}

// Make the oldest received CAN frame available,
// in the process removing it from the CAN subsystem.
// Return false (zero) if no frame available.
bool OpenLcb_can_get_frame(OpenLcbCanBuffer* b) {
  return can_get_buffered_message(b);
}
