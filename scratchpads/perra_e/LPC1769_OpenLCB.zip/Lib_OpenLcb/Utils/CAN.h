#ifndef logging_h
#define logging_h

#include <stdint.h>

#define CAN_RX_BUFFER_SIZE 20
//#define CAN_TX_BUFFER_SIZE 10

	typedef struct
	{
			uint32_t id;				//!< ID der Nachricht (11 oder 29 Bit)
			struct
			{
				int rtr : 1;			//!< Remote-Transmit-Request-Frame?
				int extended : 1;		//!< extended ID?
			} flags;

		uint8_t length;				//!< Anzahl der Datenbytes
		uint8_t data[8];			//!< Die Daten der CAN Nachricht

	} tCAN;


#endif
