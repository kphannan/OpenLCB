#ifndef EEPROM_h
#define EEPROM_h

#include <stdint.h>

/**
 * Class for handling EEPROM
 *
 * Read and Write to EEPROM
*
 */

void eeprom_init (void);

int16_t eeprom_readbuf(uint8_t* buf, uint16_t offset, uint16_t len);
int16_t eeprom_writebuf(uint8_t* buf, uint16_t offset, uint16_t len);

uint8_t EEPROM_read(int addr);
void EEPROM_write(int addr, uint8_t value );


#endif
