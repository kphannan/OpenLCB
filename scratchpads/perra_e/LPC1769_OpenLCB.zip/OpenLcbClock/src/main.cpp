/*
===============================================================================
 Name        : main.cpp
 Author      : 
 Version     :
 Copyright   : Copyright (C)
 Description : main definition
===============================================================================
*/
#include "WConstants.h"


#ifdef __USE_CMSIS
#include "LPC17xx.h"
#endif


#include <cr_section_macros.h>
#include <NXP/crp.h>

#define DebugSerial

#ifdef DebugSerial
#include "lpc17xx_pinsel.h"
#include "debug_frmwrk.h"
#endif

// OpenLCB definitions
#include "OpenLcbCanInterface.h"
#include "OpenLcbCanBuffer.h"
#include "NodeID.h"
#include "EventID.h"
#include "Event.h"


// specific OpenLCB implementations
#include "LinkControl.h"
#include "Datagram.h"
#include "OlcbStream.h"
#include "Configuration.h"
#include "NodeMemory.h"
#include "PCE.h"
#include "EEPROM.h"

// Variable to store CRP value in. Will be placed automatically
// by the linker when "Enable Code Read Protect" selected.
// See crp.h header for more information
__CRP const unsigned int CRP_WORD = CRP_NO_CRP ;


#ifdef DebugSerial
/************************** PRIVATE VARIABLES *************************/
uint8_t menu[]=
	"********************************************************************************\n\r"
	"Hello NXP Semiconductors \n\r"
	"OpenLCB Clock \n\r"
	"********************************************************************************\n\r";
void print_menu(void)
{
	_DBG_(menu);
}
#endif


OpenLcbCanBuffer     rxBuffer;	// CAN receive buffer
OpenLcbCanBuffer     txBuffer;	// CAN send buffer
OpenLcbCanBuffer*    ptxCAN;

NodeID nodeid(5,1,1,1,1,13);    // This node's default ID

LinkControl link(&txBuffer, &nodeid);
unsigned int datagramCallback(uint8_t *rbuf, unsigned int length, unsigned int from);
unsigned int streamRcvCallback(uint8_t *rbuf, unsigned int length);
void pceCallback(int index);
const uint8_t getRead(uint32_t address, int space);
void getWrite(uint32_t address, int space, uint8_t val);
void store();

// Events this node can produce or consume, used by PCE and loaded from EEPROM by NM
Event events[] = {
    Event(),  // time event xxx.hr.min
    Event(),  // rate event xxx.00.rate
    Event(),  // rate event xxx.00.rate
    Event()  // rate event xxx.00.rate
};
int eventNum = 4;



Datagram dg(&txBuffer, datagramCallback, &link);
OlcbStream str(&txBuffer, streamRcvCallback, &link);
NodeMemory nm(0);  // allocate from start of EEPROM
PCE pce(events, eventNum, &txBuffer, &nodeid, pceCallback, store);
Configuration cfg(&dg, &str, &getRead, &getWrite, (void (*)())0);


void store()
{
	nm.store(&nodeid, events, eventNum);
}

/**
 * Get and put routines that
 * use a test memory space.
 */
//TODO const configDefInfo[] PROGMEM = "OlcbBasicNode"; // null terminated string

const uint8_t getRead(uint32_t address, int space) {
  if (space == 0xFF) {
    // Configuration definition information
// TODO    return pgm_read_byte(configDefInfo+address);
	  return 0x00;
  } else if (space == 0xFE) {
    // All memory
    return *(((uint8_t*)&rxBuffer)+address);
  } else if (space == 0xFD) {
    // Configuration space
    return EEPROM_read(address);
  } else {
    // unknown space
    return 0;
  }
}
void getWrite(uint32_t address, int space, uint8_t val) {
  if (space == 0xFE) {
    // All memory
    *(((uint8_t*)&rxBuffer)+address) = val;
  } else if (space == 0xFD) {
    // Configuration space
    EEPROM_write(address, val);
  }
  // all other spaces not written
}


void pceCallback(int index){
  // invoked when an event is consumed; drive pins as needed
  // from index
  //
  // sample code uses inverse of low bit of pattern to drive pin all on or all off
  // (pattern is mostly one way, blinking the other, hence inverse)
  //

}

unsigned int datagramCallback(uint8_t *rbuf, unsigned int length, unsigned int from){
  // invoked when a datagram arrives
  //logstr("consume datagram of length ");loghex(length); lognl();
  //for (int i = 0; i<length; i++) printf("%x ", rbuf[i]);
  //printf("\n");
  // pass to consumers

	cfg.receivedDatagram(rbuf, length, from);

  return 0;  // return pre-ordained result
}

unsigned int resultcode;
unsigned int streamRcvCallback(uint8_t *rbuf, unsigned int length){
  // invoked when a stream frame arrives
  //printf("consume frame of length %d: ",length);
  //for (int i = 0; i<length; i++) printf("%x ", rbuf[i]);
  //printf("\n");
  return resultcode;  // return pre-ordained result
}



#ifdef DebugSerial
static void init_uart(void)
{
	PINSEL_CFG_Type PinCfg;
	UART_CFG_Type uartCfg;

	/* Initialize UART3 pin connect */
	PinCfg.Funcnum = 2;
	PinCfg.Pinnum = 0;
	PinCfg.Portnum = 0;
	PINSEL_ConfigPin(&PinCfg);
	PinCfg.Pinnum = 1;
	PINSEL_ConfigPin(&PinCfg);

	uartCfg.Baud_rate = 115200;
	uartCfg.Databits = UART_DATABIT_8;
	uartCfg.Parity = UART_PARITY_NONE;
	uartCfg.Stopbits = UART_STOPBIT_1;

	UART_Init(LPC_UART3, &uartCfg);

	UART_TxCmd(LPC_UART3, ENABLE);

}
#endif


int mode;
bool oldp16, oldp17, oldgold, oldblue;
int nomMode;
bool teachMode, state;
int  rate, minutes, hours;
bool  newTime, newRate, p;
int inc, newrate, newminutes, newhours;  // for teach and nominate modes
long divisor;
bool next;



void processTime()
{
    if( (nomMode==0) && !teachMode )
    {
     if(next && (millis()%divisor)==0)
     {
       minutes += 1;
       if(minutes>59)
       {
         minutes = 0;
         hours += 1;
         if(hours>23) hours = 0;
       }
       next = false;
//       sendTime(rate, hours, minutes);

       Event clockEvent = Event(0x1,0x1,0x99,0x1,0x1,0x1, hours, minutes);
       txBuffer.setProducerIdentified(&clockEvent);
       OpenLcb_can_queue_xmt_wait(&txBuffer);  // wait until buffer queued, but OK due to earlier check

     }
  }
  if((millis()%divisor)!=0)
  {
	  next = true;
  }
}


int main(void) {
	
	eeprom_init();

#ifdef DebugSerial
	init_uart();
	debug_frmwrk_init();
	print_menu();
#endif

	  //Init timer
	InitTimers();

	  // read OpenLCB from EEPROM
	  //nm.forceInitAll(); // uncomment if need to go back to initial EEPROM state
	  nm.setup(&nodeid, events, eventNum);

	  // set event types, now that IDs have been loaded from configuration
	  for (int i=0; i<4; i++) {
	      pce.newEvent(i,true,false); // produce, consume
	  }
	  for (int i=4; i<8; i++) {
	      pce.newEvent(i,false,true); // produce, consume
	  }
	  // Initialize OpenLCB CAN connection
	  OpenLcb_can_init();
	
	  // Initialize OpenLCB CAN link controller
	  link.reset();

	    hours= 9;
	    minutes = 0;
	    rate = 60;
	    divisor = 60000 / rate;


	// Enter an infinite loop, just incrementing a counter
	while(1) 
	{
		  // check for input frames, acquire if present
		  bool rcvFramePresent = OpenLcb_can_get_frame(&rxBuffer);

		  // process link control first
		  link.check();
			// if frame present, pass to handlers
			if (rcvFramePresent)
			{
			    // see if recieved frame changes link state
			    link.receivedFrame(&rxBuffer);
			}

		  // if link is initialized, higher-level operations possible
		  if (link.linkInitialized())
		  {
			// if frame present, pass to handlers
			if (rcvFramePresent) {
			    // see if recieved frame changes link state
			    link.receivedFrame(&rxBuffer);

#ifdef DebugSerial
			    _DBG("Data: ");
				for (int i = 0; i<rxBuffer.length; i++) {
					_DBH(rxBuffer.data[i]);
				}
				_DBG_("");
#endif

				pce.receivedFrame(&rxBuffer);
				dg.receivedFrame(&rxBuffer);
				str.receivedFrame(&rxBuffer);
			}

			// periodic processing of any state changes
			pce.check();
		    dg.check();
		    str.check();
		    cfg.check();

//			  processTime();
		  }
	}
	return 0 ;
}
